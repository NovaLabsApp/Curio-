// Curio : fonctionnement hors-ligne. Change le numéro de version à chaque mise à jour de l'appli.
const CACHE = 'curio-v11';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './apple-touch-icon.png'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return Promise.all(SHELL.map(function (u) { return c.add(u).catch(function () {}); })); }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) { return Promise.all(ks.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); })); }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin === location.origin) {
    // les fichiers de l'appli : réseau d'abord (toujours la dernière version), copie enregistrée si pas de connexion ou connexion trop lente
    e.respondWith(
      caches.match(req, { ignoreSearch: true }).then(function (hit) {
        const net = fetch(req).then(function (res) {
          if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then(function (c) { c.put(req, copy); }); }
          return res;
        });
        if (!hit) return net.catch(function () { return caches.match('./index.html'); });
        const slow = new Promise(function (resolve) { setTimeout(function () { resolve(hit); }, 3500); });
        return Promise.race([net, slow]).catch(function () { return hit; });
      })
    );
    return;
  }
  if (url.hostname === 'fonts.googleapis.com' || url.hostname === 'fonts.gstatic.com') {
    e.respondWith(caches.open(CACHE).then(function (c) {
      return c.match(req).then(function (hit) {
        return hit || fetch(req).then(function (res) { c.put(req, res.clone()); return res; }).catch(function () { return hit; });
      });
    }));
  }
});
